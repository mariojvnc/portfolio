﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Calculator_WPF
{
    enum BinaryOperation
    {
        Addition,
        Subtraction,
        Multiplication,
        Division,
        Power,
        None
    }

    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private BinaryOperation operation = BinaryOperation.None;
        private bool enteringANumber = false;
        private double firstOperand;
        private double memory_variable = 0;
        private bool second_switch = false;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Digit_Click(object sender, RoutedEventArgs e)
        {
            if (!(sender is Button button))
                return;

            // "1", "2", .... "9"
            int digit = 0;
            //int digit = int.Parse(button.Content.ToString());
            switch (button.Name)
            {
                case "Eins": digit = 1; break;
                case "Zwei": digit = 2; break;
                case "Drei": digit = 3; break;
                case "Vier": digit = 4; break;
                case "Fünf": digit = 5; break;
                case "Sechs": digit = 6; break;
                case "Sieben": digit = 7; break;
                case "Acht": digit = 8; break;
                case "Neun": digit = 9; break;
                case "Null": digit = 0; break;
                default: MessageBox.Show("Fatal Error"); break;
            }
            if (!enteringANumber)
            {
                Display.Content = String.Empty;
                enteringANumber = true;
            }

            Display.Content += digit.ToString();
        }

        private void Equals_Click(object sender, RoutedEventArgs e)
        {
            enteringANumber = false;

            double result = 0;
            double secondOperand = double.Parse(Display.Content.ToString());

            switch (operation)
            {
                case BinaryOperation.Addition:
                    result = firstOperand + secondOperand;
                    break;
                case BinaryOperation.Subtraction:
                    result = firstOperand - secondOperand;
                    break;
                case BinaryOperation.Multiplication:
                    result = firstOperand * secondOperand;
                    break;
                case BinaryOperation.Division:
                    result = firstOperand / secondOperand;
                    break;
                case BinaryOperation.Power:
                    result = Math.Pow(firstOperand, secondOperand);
                    break;

            }

            Display.Content = result.ToString();
        }

        private void DecimalPoint_Click(object sender, RoutedEventArgs e)
        {
            Display.Content += ",";
        }

        public void CE_Click(object sender, RoutedEventArgs e)
        {
            Display.Content = "0";
            firstOperand = 0;
        }

       

        #region Calculations
        private void Plus_Click(object sender, RoutedEventArgs e)
        {
            enteringANumber = false;
            firstOperand = double.Parse(Display.Content.ToString());

            operation = BinaryOperation.Addition;
        }
        private void Subtract_Click(object sender, RoutedEventArgs e)
        {
            enteringANumber = false;
            firstOperand = double.Parse(Display.Content.ToString());

            operation = BinaryOperation.Subtraction;
        }
        private void Multiplication_Click(object sender, RoutedEventArgs e)
        {
            enteringANumber = false;
            firstOperand = double.Parse(Display.Content.ToString());

            operation = BinaryOperation.Multiplication;
        }
        /*
         *  enteringANumber = false;
            firstOperand = double.Parse(Display.Content.ToString());

            operation = BinaryOperation.Multiplication;
         */
        private void Division_Click(object sender, RoutedEventArgs e)
        {
            enteringANumber = false;
            firstOperand = double.Parse(Display.Content.ToString());

            operation = BinaryOperation.Division;
        }
        #endregion

        #region Pi, e, x²
        private void Pi_Click(object sender, RoutedEventArgs e)
        {
            firstOperand = 3.1415926535;
            Display.Content = "3,1415926535";
        }
        private void E_number_Click(object sender, RoutedEventArgs e)
        {
            firstOperand = 2.7182818284590452353602874713527;
            Display.Content = "2,7182818284590452353602874713527";
        }
        private void X_pow_Click(object sender, RoutedEventArgs e)
        {
            //double display = double.Parse(Display.Content.ToString());
            //Display.Content = Math.Pow(display, 2).ToString();

            enteringANumber = false;
            firstOperand = double.Parse(Display.Content.ToString());

            operation = BinaryOperation.Power;
        }
        #endregion

        #region Memory
        private void Plusminus_Click(object sender, RoutedEventArgs e)
        {
            double number = double.Parse((string)Display.Content);
            number = number * -1;
            firstOperand = number;
            Display.Content = firstOperand.ToString();

        }
        private void Memory_Clear_Click(object sender, RoutedEventArgs e)
        {
            Memory_Label.Visibility = Visibility.Hidden;
            memory_variable = 0;
        }
        private void MemoryRecall_Click(object sender, RoutedEventArgs e)
        {
            Display.Content = memory_variable.ToString();
        }
        private void M_plus_Click(object sender, RoutedEventArgs e)
        {
            //enteringANumber = false;
            Memory_Label.Visibility = Visibility.Visible;
            try
            {
                memory_variable += double.Parse((string)Display.Content);

            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }
        private void M_minus_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                memory_variable -= double.Parse((string)Display.Content);

            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }
        #endregion

        #region Sin, Tan, Cos etc.
        public void Second_Click(object sender, RoutedEventArgs e)
        {
            if (!second_switch)
            {
                sinus.Visibility = cosinus.Visibility = tangens.Visibility =
                tangens_h.Visibility = sinus_h.Visibility = cosinus_h.Visibility =
                Visibility.Hidden;
                sinus_minus1.Visibility = cosinus_minus1.Visibility = tangens_minus1.Visibility =
                tangens_h_minus1.Visibility = sinus_h_minus1.Visibility = cosinus_h_minus1.Visibility =
                Visibility.Visible;

                second_switch = true;
            }
            else
            {
                sinus.Visibility = cosinus.Visibility = tangens.Visibility =
               tangens_h.Visibility = sinus_h.Visibility = cosinus_h.Visibility =
               Visibility.Visible;
                sinus_minus1.Visibility = cosinus_minus1.Visibility = tangens_minus1.Visibility =
                tangens_h_minus1.Visibility = sinus_h_minus1.Visibility = cosinus_h_minus1.Visibility =
                Visibility.Hidden;
                second_switch = false;

            }
        }
        private void Sinus_Click(object sender, RoutedEventArgs e)
        {
            double number = double.Parse((string)Display.Content);
            number = Math.Sin(number);
            Display.Content = number;
        }
        private void Cosinus_Click(object sender, RoutedEventArgs e)
        {
            double number = double.Parse((string)Display.Content);
            number = Math.Cos(number);
            Display.Content = number.ToString();
        }
        private void Tangens_Click(object sender, RoutedEventArgs e)
        {
            double number = double.Parse((string)Display.Content);
            number = Math.Tan(number);
            Display.Content = number.ToString();
        }

        private void Tangens_h_Click(object sender, RoutedEventArgs e)
        {
            double number = double.Parse((string)Display.Content);
            number = Math.Tanh(number);
            Display.Content = number.ToString();
        }
        private void Cosinus_h_Click(object sender, RoutedEventArgs e)
        {
            double number = double.Parse((string)Display.Content);
            number = Math.Cosh(number);
            Display.Content = number.ToString();
        }
        private void Sinus_h_Click(object sender, RoutedEventArgs e)
        {
            double number = double.Parse((string)Display.Content);
            number = Math.Sinh(number);
            Display.Content = number.ToString();
        }
        //
        private void Sinus_minus1_Click(object sender, RoutedEventArgs e)
        {
            double number = double.Parse((string)Display.Content);
            number = Math.Asin(number);
            Display.Content = number;
        }
        private void Cosinus_minus1_Click(object sender, RoutedEventArgs e)
        {
            double number = double.Parse((string)Display.Content);
            number = Math.Acos(number);
            Display.Content = number.ToString();
        }
        private void Tangens_minus1_Click(object sender, RoutedEventArgs e)
        {
            double number = double.Parse((string)Display.Content);
            number = Math.Atan(number);
            Display.Content = number.ToString();
        }

        private void Tangens_h_minus1_Click(object sender, RoutedEventArgs e)
        {
            double number = double.Parse((string)Display.Content);
            number = (Math.Log(1 + number) - Math.Log(1 - number)) / 2;
            Display.Content = number.ToString();
        }
        private void Cosinus_h_minus1_Click(object sender, RoutedEventArgs e)
        {
            double number = double.Parse((string)Display.Content);
            number = Math.Cosh(number); // Ich hab nicht gefunden, wie man´s berechnet
            Display.Content = number.ToString();
        }
        private void Sinus_h_minus1_Click(object sender, RoutedEventArgs e)
        {
            double number = double.Parse((string)Display.Content);
            number = Math.Sinh(number); // Ich hab nicht gefunden, wie man´s berechnet
            Display.Content = number.ToString();
        }
        #endregion

        private void Sqrt_Click(object sender, RoutedEventArgs e)
        {
            double number = double.Parse((string)Display.Content);
            number = Math.Sqrt(number);
            Display.Content = number;
        }
    }
}
