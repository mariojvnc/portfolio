﻿namespace DemoDi
{
    class Schüler
    {
        public string Name { get; private set; }

        public Schüler(string name)
        {
            Name = name;
        }
    }
}
