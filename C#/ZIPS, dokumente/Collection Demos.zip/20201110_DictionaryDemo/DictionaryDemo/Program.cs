﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DictionaryDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            // Ihr möchtet Fußballer und ihre Alter dazu speichern.
            // "Messi" -> 33
            // "Ronaldo" -> 35
            // "Ibrahimovic" -> 39
            //      Key   -> Value
            //  Schlüssel -> Wert
            Dictionary<string, int> nameToAge = new Dictionary<string, int>();
            nameToAge.Add("Messi", 33);
            nameToAge.Add("Ronaldo", 35);
            nameToAge["Ibrahimovic"] = 39;
            nameToAge["Messi"] = 34;
            // nameToAge.Add("Messi", 34); // ist nicht erlaubt

            // Ein Dictionary ist ein HashSet der Keys und an jedem Key hängt noch 
            // der Value dran.
            Console.Write("Gib einen Spieler ein: ");
            string name = Console.ReadLine();

            if (!nameToAge.ContainsKey(name))
            {
                Console.WriteLine($"{name} ist nicht gespeichert.");
            }
            else
            {
                // dictionary[ Hier kommt der Key rein ]
                int age = nameToAge[name];
                Console.WriteLine($"{name} ist {age} Jahre alt.");
            }

            Console.WriteLine(nameToAge["Messi"]);
            Console.WriteLine();

            // List<string> liste 
            // foreach( string element in liste )
            // Ausgabe eines Dictionaries
            //foreach ( KeyValuePair<string, int> element in nameToAge )
            foreach (var element in nameToAge)
            {
                Console.WriteLine($"{element.Key} -> {element.Value}");
            }

            var keys = nameToAge.Keys;
            Console.WriteLine($"Keys: {string.Join(", ", keys)}");

            var values = nameToAge.Values;
            Console.WriteLine($"Values: {string.Join(", ", values)}");

            Console.ReadKey();
        }
    }
}
